import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Health check endpoint
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", app: "Lockedin Safety Network" });
  });

  // Hoster Email Address (Kept strictly server-side, never exposed to client bundles)
  const HOSTER_EMAIL = "vishnubinu7700@gmail.com";

  // Destination Arrival Notification API
  app.post("/api/notify-arrival", async (req, res) => {
    try {
      const {
        destination,
        userName,
        receiverEmail,
        note,
        latitude,
        longitude,
        accuracy,
        timestamp,
        googleMapsUrl,
      } = req.body;

      const mapsLink =
        googleMapsUrl ||
        (latitude && longitude
          ? `https://www.google.com/maps?q=${latitude},${longitude}`
          : "Coordinates unavailable");

      const arrivalTime = timestamp
        ? new Date(timestamp).toLocaleString("en-IN", { timeZone: "Asia/Kolkata" })
        : new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata" });

      const userTag = userName?.trim() || "Traveler";
      const destTag = destination?.trim() || "Destination in Kerala";
      const targetRecipient = receiverEmail?.trim() || HOSTER_EMAIL;
      const subject = `📍 [Lockedin Kerala Arrival Alert] ${userTag} arrived safely at ${destTag}`;

      const arrivalMessage = `Hello,\n\n${userTag} has safely arrived at "${destTag}".\n\nArrival Time: ${arrivalTime} (IST)\nLive GPS Coordinates: ${latitude}, ${longitude} (Accuracy: ±${accuracy || 5}m)\nGoogle Maps Pin: ${mapsLink}\n\nNote: ${note || "Confirmed safe arrival via Lockedin Safety Network (Kerala, India)."}\n\nStay Safe,\nLockedin Kerala Safety Network`;

      const reportPayload = {
        _to: targetRecipient,
        _cc: HOSTER_EMAIL,
        recipient: targetRecipient,
        hoster_backup: HOSTER_EMAIL,
        subject,
        destination: destTag,
        traveler: userTag,
        status: "ARRIVED SAFELY (KERALA, INDIA)",
        latitude: latitude ? String(latitude) : "N/A",
        longitude: longitude ? String(longitude) : "N/A",
        accuracy_meters: accuracy ? String(accuracy) : "N/A",
        google_maps_url: mapsLink,
        arrival_time: `${arrivalTime} IST`,
        message_body: arrivalMessage,
        note: note || "Safe arrival confirmed via Lockedin beacon in Kerala, India.",
        server_dispatched_at: new Date().toISOString(),
      };

      console.log(`[Lockedin Kerala Alert] Safe arrival notification processed:`);
      console.log(` -> Sent To: ${targetRecipient}`);
      console.log(` -> Destination: ${destTag}`);
      console.log(` -> Coordinates: ${latitude}, ${longitude} (±${accuracy}m)`);
      console.log(` -> Map URL: ${mapsLink}`);
      console.log(` -> Traveler: ${userTag}`);

      // Forward to Formspree notification service in background
      try {
        await fetch("https://formspree.io/f/xyzgklmn", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
          },
          body: JSON.stringify(reportPayload),
        }).catch((err) => {
          console.warn("[Lockedin Email Service Notice]:", err.message);
        });
      } catch (dispatchErr: any) {
        console.warn("[Outbound Dispatch Fallback]:", dispatchErr?.message);
      }

      return res.status(200).json({
        success: true,
        message: `Safe arrival alert dispatched to ${targetRecipient}`,
        destination: destTag,
        receiverEmail: targetRecipient,
        arrivalTimestamp: arrivalTime,
        coordinates: {
          latitude,
          longitude,
          accuracy,
          googleMapsUrl: mapsLink,
        },
      });
    } catch (error: any) {
      console.error("[Notify Arrival API Error]:", error);
      return res.status(500).json({
        success: false,
        error: "Failed to dispatch arrival notification.",
      });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Lockedin server listening on http://localhost:${PORT}`);
  });
}

startServer();
