import React from 'react';
import { ShieldCheck, MapPin, Compass, Shield, HeartHandshake } from 'lucide-react';

export default function CreatorProfile() {
  return (
    <section id="creator-profile" className="py-12 md:py-16 scroll-mt-20 border-t border-stone-800/80">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-b from-stone-900/90 to-stone-950 border border-stone-800 rounded-3xl p-6 sm:p-8 lg:p-10 relative overflow-hidden shadow-xl">
          {/* Subtle Background Glow */}
          <div className="absolute top-0 right-0 w-72 h-72 bg-rose-600/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 flex flex-col md:flex-row items-center gap-6 md:gap-8">
            {/* Creator Monogram Icon */}
            <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-gradient-to-br from-rose-500/20 via-amber-500/20 to-rose-600/10 border-2 border-rose-500/40 flex items-center justify-center shrink-0 shadow-lg shadow-rose-950/40">
              <Shield className="w-10 h-10 sm:w-12 sm:h-12 text-rose-400" />
            </div>

            {/* Creator Bio & Attribution */}
            <div className="flex flex-col text-center md:text-left gap-2 flex-1">
              <div className="inline-flex items-center justify-center md:justify-start gap-2 text-xs font-semibold text-rose-400 uppercase tracking-wider">
                <ShieldCheck className="w-4 h-4" />
                <span>Lockedin Personal Safety Network</span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight font-['Space_Grotesk']">
                Created by Vishnu Binu
              </h3>
              <p className="text-stone-300 text-xs sm:text-sm leading-relaxed max-w-2xl">
                Conceived and engineered for the community in Kerala, India. Lockedin provides rapid satellite location broadcasting, automated destination arrival alerts to guardians and friends, and immediate one-touch emergency helplines.
              </p>

              <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 pt-2">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-stone-900 border border-stone-700 text-stone-300 text-xs font-medium">
                  <MapPin className="w-3.5 h-3.5 text-rose-400" />
                  Kerala, India
                </span>
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-stone-900 border border-stone-700 text-stone-300 text-xs font-medium">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  Creator & Architect: Vishnu Binu
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
