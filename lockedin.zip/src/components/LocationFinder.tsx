import React, { useState, useEffect } from 'react';
import {
  MapPin,
  Send,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Copy,
  Check,
  Settings2,
  Navigation,
  Compass,
  Clock,
  ShieldCheck,
  RefreshCw,
  Share2,
  MessageSquare
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { LocationData, StepStatus } from '../types';

interface LocationFinderProps {
  onLocationCaptured?: (loc: LocationData) => void;
}

export default function LocationFinder({ onLocationCaptured }: LocationFinderProps) {
  const [status, setStatus] = useState<StepStatus>('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [errorDetails, setErrorDetails] = useState<string | null>(null);
  const [location, setLocation] = useState<LocationData | null>(null);
  const [copied, setCopied] = useState(false);

  // Formspree endpoint management
  const [formspreeEndpoint, setFormspreeEndpoint] = useState<string>(() => {
    return localStorage.getItem('lockedin_formspree') || 'https://formspree.io/f/xyzgklmn';
  });
  const [showConfig, setShowConfig] = useState(false);
  const [senderName, setSenderName] = useState('');
  const [customNote, setCustomNote] = useState('');
  const [formspreeSuccess, setFormspreeSuccess] = useState<boolean>(false);

  useEffect(() => {
    localStorage.setItem('lockedin_formspree', formspreeEndpoint);
  }, [formspreeEndpoint]);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleFindLocation = () => {
    setErrorMessage(null);
    setErrorDetails(null);
    setStatus('locating');

    if (!navigator.geolocation) {
      setStatus('error');
      setErrorMessage('Geolocation is not supported by your browser.');
      setErrorDetails('Please upgrade your browser or switch to a device equipped with HTML5 location services.');
      return;
    }

    const geoOptions: PositionOptions = {
      enableHighAccuracy: true,
      timeout: 15000,
      maximumAge: 0,
    };

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude, accuracy, altitude, speed, heading } = position.coords;
        const formattedTimestamp = new Date(position.timestamp).toISOString();
        const googleMapsUrl = `https://www.google.com/maps?q=${latitude},${longitude}`;
        const osmUrl = `https://www.openstreetmap.org/?mlat=${latitude}&mlon=${longitude}#map=16/${latitude}/${longitude}`;
        const appleMapsUrl = `https://maps.apple.com/?ll=${latitude},${longitude}&q=Current+Location`;

        const locData: LocationData = {
          latitude,
          longitude,
          accuracy: Math.round(accuracy),
          altitude: altitude ? Math.round(altitude) : null,
          speed: speed ? Math.round(speed) : null,
          heading: heading ? Math.round(heading) : null,
          timestamp: formattedTimestamp,
          googleMapsUrl,
          osmUrl,
          appleMapsUrl,
        };

        setLocation(locData);
        if (onLocationCaptured) {
          onLocationCaptured(locData);
        }
        setStatus('sending');

        // Transmit coordinates to Formspree
        try {
          let targetUrl = formspreeEndpoint.trim();
          if (!targetUrl.startsWith('http://') && !targetUrl.startsWith('https://')) {
            targetUrl = `https://formspree.io/f/${targetUrl}`;
          }

          const payload = {
            subject: `🔒 Lockedin Alert: Location Found (${latitude.toFixed(5)}, ${longitude.toFixed(5)})`,
            message: `📍 Lockedin Safety Network - Location Found Report:\n\n` +
              `• Google Maps: ${googleMapsUrl}\n` +
              `• Apple Maps: ${appleMapsUrl}\n` +
              `• Coordinates: ${latitude.toFixed(6)}, ${longitude.toFixed(6)}\n` +
              `• GPS Accuracy: ±${Math.round(accuracy)} meters\n` +
              `• Recorded Time: ${new Date(position.timestamp).toLocaleString()}\n` +
              (senderName ? `• Target / User Name: ${senderName}\n` : '') +
              (customNote ? `• Note / Situation: ${customNote}\n` : ''),
            latitude: latitude.toString(),
            longitude: longitude.toString(),
            accuracy_meters: Math.round(accuracy).toString(),
            google_maps_url: googleMapsUrl,
            apple_maps_url: appleMapsUrl,
            target_name: senderName || 'Anonymous',
            situation_note: customNote || 'Standard Check',
            captured_at: new Date(position.timestamp).toLocaleString(),
            user_agent: navigator.userAgent,
          };

          const response = await fetch(targetUrl, {
            method: 'POST',
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(payload),
          });

          if (response.ok) {
            setFormspreeSuccess(true);
            setStatus('success');
          } else {
            const data = await response.json().catch(() => ({}));
            if (response.status === 404 || response.status === 422) {
              setErrorMessage('Location captured, but Formspree endpoint returned a response issue.');
              setErrorDetails(
                data?.error ||
                'To receive email alerts, ensure you provide a valid Formspree Form ID in the settings gear above.'
              );
              setFormspreeSuccess(false);
              setStatus('success'); // Still show captured coordinates
            } else {
              throw new Error(data?.error || `Server responded with status ${response.status}`);
            }
          }
        } catch (fetchErr: any) {
          console.error('Formspree dispatch notice:', fetchErr);
          setFormspreeSuccess(false);
          setErrorMessage('Could not connect to Formspree email endpoint.');
          setErrorDetails(fetchErr?.message || 'Check your internet connection or Formspree endpoint ID.');
          setStatus('success');
        }
      },
      (error: GeolocationPositionError) => {
        setStatus('error');
        switch (error.code) {
          case error.PERMISSION_DENIED:
            setErrorMessage('Location Access Permission Denied.');
            setErrorDetails(
              'Your browser blocked location access. Please click the permissions icon (padlock/tune) in your browser address bar and enable "Location" to find and transmit coordinates.'
            );
            break;
          case error.POSITION_UNAVAILABLE:
            setErrorMessage('Location Position Unavailable.');
            setErrorDetails(
              'GPS hardware could not determine current coordinates. Ensure Location Services / GPS are switched ON in your device settings.'
            );
            break;
          case error.TIMEOUT:
            setErrorMessage('Location Request Timed Out.');
            setErrorDetails(
              'The GPS signal took too long to resolve. Please move closer to an open window or clear sky and try again.'
            );
            break;
          default:
            setErrorMessage('An unexpected error occurred.');
            setErrorDetails(error.message || 'Please verify device permissions and try again.');
        }
      },
      geoOptions
    );
  };

  const handleReset = () => {
    setStatus('idle');
    setErrorMessage(null);
    setErrorDetails(null);
  };

  return (
    <section id="location-finder" className="py-12 md:py-16 scroll-mt-20">
      <div className="max-w-3xl mx-auto px-4 sm:px-6">
        <div className="bg-stone-900/80 backdrop-blur-xl border border-stone-800 rounded-2xl shadow-2xl p-6 sm:p-8 flex flex-col gap-6 relative overflow-hidden">
          {/* Top Decorative Strip */}
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-rose-500 via-amber-500 to-rose-500" />

          {/* Header */}
          <div className="flex items-center justify-between border-b border-stone-800/80 pb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400">
                <MapPin className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
                  Live Location Beacon
                </h2>
                <p className="text-xs text-stone-400">HTML5 Geolocation Signal & Instant Formspree Dispatch</p>
              </div>
            </div>

            <button
              id="location-config-toggle"
              onClick={() => setShowConfig(!showConfig)}
              className="p-2 text-stone-400 hover:text-stone-100 hover:bg-stone-800 rounded-lg transition-colors border border-stone-800"
              title="Configure Formspree Endpoint"
              aria-label="Settings"
            >
              <Settings2 className="w-4 h-4" />
            </button>
          </div>

          {/* Configuration Form (Collapsible) */}
          <AnimatePresence>
            {showConfig && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden"
              >
                <div className="bg-stone-950/80 border border-stone-800 rounded-xl p-4 flex flex-col gap-3 text-xs">
                  <div className="flex items-center gap-2 font-medium text-stone-200">
                    <ShieldCheck className="w-4 h-4 text-rose-400" />
                    <span>Formspree Delivery Settings</span>
                  </div>
                  <div>
                    <label className="block text-stone-400 mb-1" htmlFor="formspree-input">
                      Formspree Form URL or ID:
                    </label>
                    <input
                      id="formspree-input"
                      type="text"
                      value={formspreeEndpoint}
                      onChange={(e) => setFormspreeEndpoint(e.target.value)}
                      placeholder="https://formspree.io/f/your_form_id"
                      className="w-full bg-stone-900 border border-stone-700 rounded-lg px-3 py-2 text-stone-200 focus:outline-none focus:border-rose-500 font-mono text-[11px]"
                    />
                    <p className="text-[10px] text-stone-500 mt-1">
                      Emails with live Google Maps links will be sent here upon coordinate acquisition.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                    <div>
                      <label className="block text-stone-400 mb-1" htmlFor="target-name-input">
                        Target Name / Device ID (Optional):
                      </label>
                      <input
                        id="target-name-input"
                        type="text"
                        value={senderName}
                        onChange={(e) => setSenderName(e.target.value)}
                        placeholder="e.g., Vishnu Binu / Car Beacon"
                        className="w-full bg-stone-900 border border-stone-700 rounded-lg px-3 py-1.5 text-stone-200 focus:outline-none focus:border-rose-500 text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-stone-400 mb-1" htmlFor="safety-note-input">
                        Emergency Note (Optional):
                      </label>
                      <input
                        id="safety-note-input"
                        type="text"
                        value={customNote}
                        onChange={(e) => setCustomNote(e.target.value)}
                        placeholder="e.g., Highway breakdown / Solo ride"
                        className="w-full bg-stone-900 border border-stone-700 rounded-lg px-3 py-1.5 text-stone-200 focus:outline-none focus:border-rose-500 text-xs"
                      />
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* MAIN BUTTON: "Find Their Location" */}
          <div className="flex flex-col items-center gap-3">
            <button
              id="find-their-location-btn"
              onClick={handleFindLocation}
              disabled={status === 'locating' || status === 'sending'}
              className={`w-full group relative overflow-hidden py-4 px-6 rounded-xl font-bold text-base transition-all duration-200 flex items-center justify-center gap-3 shadow-xl cursor-pointer ${
                status === 'locating' || status === 'sending'
                  ? 'bg-stone-800 text-stone-400 cursor-not-allowed border border-stone-700'
                  : 'bg-gradient-to-r from-rose-600 via-rose-500 to-amber-600 hover:from-rose-500 hover:to-amber-500 text-white shadow-rose-950/60 hover:shadow-rose-900/80 active:scale-[0.99] border border-rose-400/30'
              }`}
            >
              {status === 'locating' ? (
                <>
                  <RefreshCw className="w-5 h-5 animate-spin text-rose-300" />
                  <span>Locking Onto GPS Satellite Signal...</span>
                </>
              ) : status === 'sending' ? (
                <>
                  <Send className="w-5 h-5 animate-pulse text-amber-300" />
                  <span>Transmitting Coordinates to Formspree...</span>
                </>
              ) : (
                <>
                  <Navigation className="w-5 h-5 transition-transform group-hover:rotate-12 group-hover:scale-110 text-white" />
                  <span className="tracking-wide text-lg">Find Their Location</span>
                </>
              )}
            </button>

            {status === 'idle' && (
              <p className="text-xs text-stone-400 flex items-center gap-1.5 text-center">
                <ShieldCheck className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                <span>Requests browser GPS permission, locks coordinates, and broadcasts the Google Maps location.</span>
              </p>
            )}
          </div>

          {/* Error Notice */}
          <AnimatePresence>
            {status === 'error' && errorMessage && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="bg-rose-950/50 border border-rose-800/90 rounded-xl p-4 text-rose-200 flex flex-col gap-2"
              >
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <h3 className="font-semibold text-sm text-rose-100">{errorMessage}</h3>
                    {errorDetails && (
                      <p className="text-xs text-rose-300/80 mt-1 leading-relaxed">{errorDetails}</p>
                    )}
                  </div>
                </div>

                <div className="flex justify-end gap-2 pt-2 border-t border-rose-900/50 mt-1">
                  <button
                    onClick={handleReset}
                    className="px-3 py-1.5 text-xs bg-rose-900/40 hover:bg-rose-900/70 border border-rose-700/50 rounded-lg text-rose-200 transition-colors"
                  >
                    Dismiss
                  </button>
                  <button
                    onClick={handleFindLocation}
                    className="px-3 py-1.5 text-xs bg-rose-600 hover:bg-rose-500 text-white rounded-lg transition-colors font-medium cursor-pointer"
                  >
                    Try Again
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Success Location Presentation */}
          <AnimatePresence>
            {status === 'success' && location && (
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex flex-col gap-4"
              >
                {/* Delivery Badge */}
                {formspreeSuccess ? (
                  <div className="bg-emerald-950/50 border border-emerald-800/80 rounded-xl p-3.5 flex items-center gap-3 text-emerald-200 text-xs">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <div className="flex-1">
                      <span className="font-semibold text-emerald-100">Location Captured & Dispatched!</span>
                      <p className="text-emerald-300/80 text-[11px]">
                        The coordinates and Google Maps link have been sent to Formspree.
                      </p>
                    </div>
                  </div>
                ) : errorMessage ? (
                  <div className="bg-amber-950/50 border border-amber-800/80 rounded-xl p-3.5 flex items-start gap-3 text-amber-200 text-xs">
                    <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <span className="font-semibold text-amber-100">GPS Locked (Transmission Notice)</span>
                      <p className="text-amber-300/80 text-[11px] mt-0.5">{errorDetails || errorMessage}</p>
                    </div>
                  </div>
                ) : null}

                {/* Captured GPS Card */}
                <div className="bg-stone-950 border border-stone-800 rounded-xl p-4 sm:p-5 flex flex-col gap-4">
                  <div className="flex items-center justify-between border-b border-stone-800/80 pb-3">
                    <div className="flex items-center gap-2 text-stone-200 font-semibold text-sm">
                      <Compass className="w-4 h-4 text-rose-400" />
                      <span>Live Coordinate Readings</span>
                    </div>
                    <span className="text-[11px] bg-stone-900 text-rose-300 px-2.5 py-0.5 rounded-full border border-rose-900/50 font-mono">
                      Radius: ±{location.accuracy}m
                    </span>
                  </div>

                  {/* Coordinates Grid */}
                  <div className="grid grid-cols-2 gap-3 font-mono text-xs">
                    <div className="bg-stone-900/80 p-3 rounded-lg border border-stone-800">
                      <span className="text-[10px] uppercase tracking-wider text-stone-400 block mb-1">Latitude</span>
                      <span className="text-white text-sm font-bold">{location.latitude.toFixed(6)}°</span>
                    </div>
                    <div className="bg-stone-900/80 p-3 rounded-lg border border-stone-800">
                      <span className="text-[10px] uppercase tracking-wider text-stone-400 block mb-1">Longitude</span>
                      <span className="text-white text-sm font-bold">{location.longitude.toFixed(6)}°</span>
                    </div>
                  </div>

                  {/* Speed & Altitude if available */}
                  {(location.speed !== null || location.altitude !== null) && (
                    <div className="grid grid-cols-2 gap-3 font-mono text-[11px]">
                      {location.speed !== null && (
                        <div className="bg-stone-900/50 p-2 rounded-lg border border-stone-800/60 text-stone-300">
                          <span className="text-stone-500 block text-[10px]">Speed</span>
                          {Math.round(location.speed * 3.6)} km/h
                        </div>
                      )}
                      {location.altitude !== null && (
                        <div className="bg-stone-900/50 p-2 rounded-lg border border-stone-800/60 text-stone-300">
                          <span className="text-stone-500 block text-[10px]">Altitude</span>
                          {location.altitude}m
                        </div>
                      )}
                    </div>
                  )}

                  {/* Timestamp */}
                  <div className="flex items-center gap-2 text-xs text-stone-400">
                    <Clock className="w-3.5 h-3.5 text-stone-500 shrink-0" />
                    <span>Locked at {new Date(location.timestamp).toLocaleTimeString()} on {new Date(location.timestamp).toLocaleDateString()}</span>
                  </div>

                  {/* Navigation Links */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2">
                    <a
                      id="view-google-maps-btn"
                      href={location.googleMapsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 hover:text-rose-200 border border-rose-500/30 px-4 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
                    >
                      <MapPin className="w-3.5 h-3.5 text-rose-400" />
                      <span>Open in Google Maps</span>
                      <ExternalLink className="w-3.5 h-3.5 opacity-70" />
                    </a>

                    <a
                      id="view-apple-maps-btn"
                      href={location.appleMapsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-stone-900 hover:bg-stone-800 text-stone-200 border border-stone-700 px-4 py-2.5 rounded-lg text-xs font-medium flex items-center justify-center gap-2 transition-colors"
                    >
                      <span>Apple Maps / iOS</span>
                      <ExternalLink className="w-3.5 h-3.5 opacity-70" />
                    </a>
                  </div>

                  {/* Quick Share Buttons */}
                  <div className="flex flex-wrap gap-2 pt-1 border-t border-stone-900">
                    <button
                      id="copy-coordinates-action"
                      onClick={() => handleCopy(`${location.latitude}, ${location.longitude}`)}
                      className="flex-1 bg-stone-900 hover:bg-stone-800 text-stone-300 px-3 py-2 rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 border border-stone-800 transition-colors"
                    >
                      {copied ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-emerald-400 font-semibold">Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5 text-stone-400" />
                          <span>Copy Lat/Lng</span>
                        </>
                      )}
                    </button>

                    <a
                      id="whatsapp-share-link"
                      href={`https://wa.me/?text=${encodeURIComponent(`📍 Lockedin Location Beacon: ${location.googleMapsUrl} (${location.latitude}, ${location.longitude})`)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-emerald-950/60 hover:bg-emerald-900/60 text-emerald-300 border border-emerald-800/80 px-3 py-2 rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <Share2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>WhatsApp</span>
                    </a>

                    <a
                      id="sms-share-link"
                      href={`sms:?&body=${encodeURIComponent(`📍 Lockedin Location Beacon: ${location.googleMapsUrl}`)}`}
                      className="bg-amber-950/60 hover:bg-amber-900/60 text-amber-300 border border-amber-800/80 px-3 py-2 rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <MessageSquare className="w-3.5 h-3.5 text-amber-400" />
                      <span>SMS</span>
                    </a>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
