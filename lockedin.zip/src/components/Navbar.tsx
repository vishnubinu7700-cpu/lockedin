import React from 'react';
import { Shield, MapPin, BellRing, User, Activity, AlertTriangle } from 'lucide-react';

interface NavbarProps {
  onSirenToggle: () => void;
  isSirenActive: boolean;
}

export default function Navbar({ onSirenToggle, isSirenActive }: NavbarProps) {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-stone-800/80 bg-stone-950/85 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand Logo */}
        <a href="#" className="flex items-center gap-3 group">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-rose-500 to-amber-600 p-0.5 shadow-lg shadow-rose-950/40">
            <div className="w-full h-full bg-stone-950 rounded-[10px] flex items-center justify-center">
              <Shield className="w-5 h-5 text-rose-500 group-hover:scale-110 transition-transform" />
            </div>
          </div>
          <div className="flex flex-col">
            <span className="font-bold text-lg tracking-tight text-white flex items-center gap-1.5 font-['Space_Grotesk']">
              Lockedin
              <span className="inline-block w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
            </span>
            <span className="text-[10px] text-emerald-400 font-medium tracking-wider">
              Kerala, India • Safety Beacon
            </span>
          </div>
        </a>

        {/* Navigation Links */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-stone-300">
          <a href="#location-finder" className="hover:text-rose-400 transition-colors flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 text-rose-400" />
            Find Location
          </a>
          <a href="#destination-arrival" className="hover:text-emerald-400 transition-colors flex items-center gap-1.5">
            <Shield className="w-3.5 h-3.5 text-emerald-400" />
            Send Arrival Email
          </a>
          <a href="#safety-suite" className="hover:text-amber-400 transition-colors flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-amber-400" />
            Kerala Helplines & SOS
          </a>
          <a href="#roadside-guide" className="hover:text-orange-400 transition-colors flex items-center gap-1.5">
            <AlertTriangle className="w-3.5 h-3.5 text-orange-400" />
            Roadside Safety
          </a>
          <a href="#creator-profile" className="hover:text-rose-400 transition-colors flex items-center gap-1.5">
            <User className="w-3.5 h-3.5 text-rose-400" />
            Created by Vishnu Binu
          </a>
        </nav>

        {/* Quick Emergency Siren Button */}
        <div className="flex items-center gap-3">
          <button
            id="nav-siren-btn"
            onClick={onSirenToggle}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all shadow-md cursor-pointer ${
              isSirenActive
                ? 'bg-rose-600 text-white animate-bounce shadow-rose-600/50'
                : 'bg-rose-950/60 text-rose-300 border border-rose-800/80 hover:bg-rose-900/60 hover:text-white'
            }`}
          >
            <BellRing className={`w-3.5 h-3.5 ${isSirenActive ? 'animate-spin' : ''}`} />
            <span>{isSirenActive ? 'STOP ALARM' : 'SOS Siren'}</span>
          </button>
        </div>
      </div>
    </header>
  );
}
