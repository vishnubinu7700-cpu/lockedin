import React from 'react';
import { ShieldCheck, MapPin, Radio, Compass, Activity, Car, HeartHandshake, Mail } from 'lucide-react';
import { motion } from 'motion/react';

interface HeroSectionProps {
  onScrollToFinder: () => void;
  onScrollToSafety: () => void;
}

export default function HeroSection({ onScrollToFinder, onScrollToSafety }: HeroSectionProps) {
  return (
    <section className="relative overflow-hidden pt-12 pb-16 md:pt-20 md:pb-24 border-b border-stone-800/60">
      {/* Dynamic Background Glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-gradient-to-tr from-rose-600/15 via-amber-600/10 to-transparent rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-0 right-10 w-72 h-72 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto flex flex-col items-center gap-6">
          {/* Kerala India Badge */}
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-stone-900/90 border border-emerald-500/40 text-emerald-300 text-xs font-medium shadow-inner"
          >
            <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span>Kerala, India • Live GPS Safety & Arrival Network</span>
          </motion.div>

          {/* Heading */}
          <motion.h1
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-3xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-[1.15] font-['Space_Grotesk']"
          >
            Real-Time Location &{' '}
            <span className="bg-gradient-to-r from-rose-400 via-rose-500 to-amber-400 bg-clip-text text-transparent">
              Kerala Emergency Protection
            </span>
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-stone-300 text-base sm:text-lg max-w-2xl leading-relaxed"
          >
            Built for travelers, students, solo commuters, and motorists across Kerala. Instant GPS coordinate transmission, customizable arrival emails to your family or friends, loud SOS siren alarms, and Kerala Police helplines.
          </motion.p>

          {/* Primary Action Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center gap-3.5 w-full sm:w-auto pt-2"
          >
            <button
              id="hero-find-location-btn"
              onClick={onScrollToFinder}
              className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-gradient-to-r from-rose-600 via-rose-500 to-amber-600 hover:from-rose-500 hover:to-amber-500 text-white font-semibold text-sm shadow-xl shadow-rose-950/60 hover:shadow-rose-900/80 flex items-center justify-center gap-2.5 transition-all transform active:scale-95 border border-rose-400/30 cursor-pointer"
            >
              <MapPin className="w-4 h-4" />
              <span>Find Their Location</span>
            </button>

            <a
              id="hero-arrival-alert-btn"
              href="#destination-arrival"
              className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-emerald-950/80 hover:bg-emerald-900/80 text-emerald-200 hover:text-white font-semibold text-sm border border-emerald-600/50 flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg shadow-emerald-950/40"
            >
              <Mail className="w-4 h-4 text-emerald-400" />
              <span>Send Arrival Email</span>
            </a>

            <button
              id="hero-explore-safety-btn"
              onClick={onScrollToSafety}
              className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-stone-900/90 hover:bg-stone-800 text-stone-200 hover:text-white font-medium text-sm border border-stone-700/80 hover:border-stone-600 flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Activity className="w-4 h-4 text-amber-400" />
              <span>Kerala Helplines & SOS</span>
            </button>
          </motion.div>

          {/* Key Value Props Bar */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 w-full pt-8"
          >
            <div className="bg-stone-900/60 border border-stone-800/80 rounded-xl p-3.5 flex flex-col items-center text-center">
              <Compass className="w-5 h-5 text-rose-400 mb-1.5" />
              <span className="font-semibold text-white text-xs sm:text-sm">High-Precision GPS</span>
              <span className="text-[11px] text-stone-400">Accurate Kerala coordinate lock</span>
            </div>

            <div className="bg-stone-900/60 border border-stone-800/80 rounded-xl p-3.5 flex flex-col items-center text-center">
              <Mail className="w-5 h-5 text-emerald-400 mb-1.5" />
              <span className="font-semibold text-white text-xs sm:text-sm">Custom Arrival Email</span>
              <span className="text-[11px] text-stone-400">Notify family & guardians</span>
            </div>

            <div className="bg-stone-900/60 border border-stone-800/80 rounded-xl p-3.5 flex flex-col items-center text-center">
              <Activity className="w-5 h-5 text-amber-400 mb-1.5" />
              <span className="font-semibold text-white text-xs sm:text-sm">Kerala Police Helplines</span>
              <span className="text-[11px] text-stone-400">112, 100, 1515 Pink Police</span>
            </div>

            <div className="bg-stone-900/60 border border-stone-800/80 rounded-xl p-3.5 flex flex-col items-center text-center">
              <Car className="w-5 h-5 text-orange-400 mb-1.5" />
              <span className="font-semibold text-white text-xs sm:text-sm">Kerala Roadside Guide</span>
              <span className="text-[11px] text-stone-400">Monsoon & ghat road protocols</span>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
