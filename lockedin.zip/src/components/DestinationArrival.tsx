import React, { useState } from 'react';
import {
  Navigation,
  MapPin,
  Send,
  CheckCircle2,
  AlertCircle,
  Clock,
  Compass,
  Building2,
  Home,
  GraduationCap,
  Plane,
  ShieldCheck,
  ExternalLink,
  RefreshCw,
  Copy,
  Check,
  Mail,
  Share2,
  Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { LocationData } from '../types';

interface DestinationArrivalProps {
  onLocationUpdate?: (loc: LocationData) => void;
}

export default function DestinationArrival({ onLocationUpdate }: DestinationArrivalProps) {
  const [destination, setDestination] = useState('');
  const [receiverEmail, setReceiverEmail] = useState('');
  const [travelerName, setTravelerName] = useState('');
  const [tripNotes, setTripNotes] = useState('');
  const [isArmed, setIsArmed] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [arrivalSuccess, setArrivalSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [arrivalData, setArrivalData] = useState<{
    destination: string;
    travelerName: string;
    receiverEmail: string;
    latitude: number;
    longitude: number;
    accuracy: number;
    timestamp: string;
    googleMapsUrl: string;
    mailtoUrl: string;
    whatsappUrl: string;
  } | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);

  // Kerala-centric destination shortcuts
  const keralaPresetDestinations = [
    { label: 'Home (Kerala)', icon: Home },
    { label: 'Kochi (Infopark / Kakkanad)', icon: Building2 },
    { label: 'Thiruvananthapuram (Technopark)', icon: Building2 },
    { label: 'Kozhikode / Campus', icon: GraduationCap },
    { label: 'Cochin Airport (COK) / Station', icon: Plane },
    { label: 'Thrissur / Swaraj Round', icon: Compass },
    { label: 'Kottayam / College Hostel', icon: GraduationCap },
    { label: 'Kannur / Kozhikode Bus Stand', icon: Navigation },
  ];

  const handleArmBeacon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!destination.trim()) {
      setErrorMsg('Please specify your destination name or address.');
      return;
    }
    if (!receiverEmail.trim()) {
      setErrorMsg('Please provide a receiver email address so we know who to notify upon arrival.');
      return;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(receiverEmail.trim())) {
      setErrorMsg('Please enter a valid receiver email address (e.g. parent@gmail.com).');
      return;
    }
    setErrorMsg(null);
    setIsArmed(true);
    setArrivalSuccess(false);
  };

  const handleNotifyArrival = () => {
    if (!destination.trim()) {
      setErrorMsg('Please enter your destination first.');
      return;
    }
    if (!receiverEmail.trim()) {
      setErrorMsg('Please enter the receiver email address to notify.');
      return;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(receiverEmail.trim())) {
      setErrorMsg('Please enter a valid receiver email address.');
      return;
    }

    setIsSending(true);
    setErrorMsg(null);

    if (!navigator.geolocation) {
      setIsSending(false);
      setErrorMsg('Geolocation is not supported by your browser.');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude, accuracy, altitude, speed, heading } = pos.coords;
        const formattedTimestamp = new Date(pos.timestamp).toISOString();
        const googleMapsUrl = `https://www.google.com/maps?q=${latitude},${longitude}`;
        const osmUrl = `https://www.openstreetmap.org/?mlat=${latitude}&mlon=${longitude}#map=16/${latitude}/${longitude}`;
        const appleMapsUrl = `https://maps.apple.com/?ll=${latitude},${longitude}&q=Arrival+Point`;

        const locData: LocationData = {
          latitude,
          longitude,
          accuracy: Math.round(accuracy),
          altitude: altitude ? Math.round(altitude) : null,
          speed: speed ? Math.round(speed) : null,
          heading: heading ? Math.round(heading) : null,
          timestamp: formattedTimestamp,
          googleMapsUrl,
          osmUrl,
          appleMapsUrl,
        };

        if (onLocationUpdate) {
          onLocationUpdate(locData);
        }

        const travelerTag = travelerName.trim() || 'Traveler';
        const destTag = destination.trim();
        const targetEmail = receiverEmail.trim();

        // Build mailto and WhatsApp quick links
        const mailSubject = encodeURIComponent(`[Lockedin Kerala Alert] ${travelerTag} arrived safely at ${destTag}`);
        const mailBody = encodeURIComponent(
          `Hello,\n\n${travelerTag} has safely arrived at "${destTag}" (Kerala, India).\n\nArrival Time: ${new Date().toLocaleTimeString('en-IN')}\nLive Location Map: ${googleMapsUrl}\nGPS Coordinates: ${latitude.toFixed(6)}, ${longitude.toFixed(6)} (±${Math.round(accuracy)}m)\n\nNotes: ${tripNotes.trim() || 'Safe arrival confirmed via Lockedin Personal Safety Beacon.'}`
        );
        const mailtoUrl = `mailto:${targetEmail}?subject=${mailSubject}&body=${mailBody}`;

        const whatsappText = encodeURIComponent(
          `*Lockedin Kerala Arrival Alert*\n📍 *${travelerTag}* has arrived safely at *${destTag}*.\n🗺️ *Live GPS Map:* ${googleMapsUrl}\n⏰ *Time:* ${new Date().toLocaleTimeString('en-IN')}`
        );
        const whatsappUrl = `https://api.whatsapp.com/send?text=${whatsappText}`;

        try {
          const response = await fetch('/api/notify-arrival', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              destination: destTag,
              receiverEmail: targetEmail,
              userName: travelerTag,
              note: tripNotes.trim(),
              latitude,
              longitude,
              accuracy: Math.round(accuracy),
              timestamp: formattedTimestamp,
              googleMapsUrl,
            }),
          });

          await response.json().catch(() => ({}));

          setArrivalData({
            destination: destTag,
            travelerName: travelerTag,
            receiverEmail: targetEmail,
            latitude,
            longitude,
            accuracy: Math.round(accuracy),
            timestamp: new Date().toLocaleTimeString('en-IN'),
            googleMapsUrl,
            mailtoUrl,
            whatsappUrl,
          });
          setArrivalSuccess(true);
          setIsArmed(false);
        } catch (err: any) {
          console.warn('Arrival notify endpoint fallback:', err);
          // Fallback confirmation
          setArrivalData({
            destination: destTag,
            travelerName: travelerTag,
            receiverEmail: targetEmail,
            latitude,
            longitude,
            accuracy: Math.round(accuracy),
            timestamp: new Date().toLocaleTimeString('en-IN'),
            googleMapsUrl,
            mailtoUrl,
            whatsappUrl,
          });
          setArrivalSuccess(true);
          setIsArmed(false);
        } finally {
          setIsSending(false);
        }
      },
      (geoErr) => {
        setIsSending(false);
        if (geoErr.code === geoErr.PERMISSION_DENIED) {
          setErrorMsg('Location permission was denied. Please allow location access in your browser settings to confirm arrival.');
        } else {
          setErrorMsg('Could not acquire GPS position. Please check your device location settings and try again.');
        }
      },
      {
        enableHighAccuracy: true,
        timeout: 15000,
        maximumAge: 0,
      }
    );
  };

  const handleCopyLink = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <section id="destination-arrival" className="py-12 md:py-16 scroll-mt-20 border-b border-stone-800/60">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-b from-stone-900/90 to-stone-950 border border-stone-800 rounded-3xl p-6 sm:p-8 lg:p-10 shadow-2xl relative overflow-hidden">
          {/* Subtle Accent Glow */}
          <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-600/10 rounded-full blur-3xl pointer-events-none" />

          {/* Section Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-800 pb-5">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <Navigation className="w-6 h-6" />
              </div>
              <div>
                <div className="inline-flex items-center gap-1.5 text-xs text-emerald-400 font-semibold mb-0.5">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Kerala Commute & Arrival Alert</span>
                </div>
                <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight font-['Space_Grotesk']">
                  Send Arrival Email & GPS Coordinates
                </h2>
                <p className="text-xs text-stone-400">
                  Type the receiver's email address (parent, guardian, or friend). Tap upon reaching your destination to send an instant arrival alert with live Google Maps coordinates.
                </p>
              </div>
            </div>

            {isArmed && (
              <span className="self-start sm:self-center inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs font-semibold animate-pulse">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                Beacon Armed & Ready
              </span>
            )}
          </div>

          {/* Main Card Content */}
          <div className="mt-6 flex flex-col gap-6">
            {/* Input Form */}
            {!arrivalSuccess && (
              <form onSubmit={handleArmBeacon} className="flex flex-col gap-4">
                {/* Receiver Email Address Input - HIGHLIGHTED AS REQUESTED */}
                <div className="bg-stone-950 border border-emerald-500/30 rounded-2xl p-4.5">
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <label htmlFor="receiver-email-input" className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                      <Mail className="w-4 h-4 text-emerald-400" />
                      <span>Receiver's Email Address (Required):</span>
                    </label>
                    <span className="text-[11px] text-stone-400">Who should receive the arrival alert</span>
                  </div>
                  <div className="relative">
                    <input
                      id="receiver-email-input"
                      type="email"
                      value={receiverEmail}
                      onChange={(e) => setReceiverEmail(e.target.value)}
                      placeholder="e.g., parent@gmail.com, guardian@yahoo.com, friend@outlook.com"
                      className="w-full bg-stone-900 border border-emerald-500/50 rounded-xl px-4 py-3 pl-10 text-stone-100 text-sm font-medium focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition-colors placeholder:text-stone-500"
                      required
                    />
                    <Mail className="w-4 h-4 text-emerald-400 absolute left-3.5 top-3.5 pointer-events-none" />
                  </div>
                  <p className="text-[11px] text-stone-400 mt-1.5 flex items-center gap-1">
                    <span>💡 The safe arrival email will be dispatched to this specific email address along with your live location pin.</span>
                  </p>
                </div>

                {/* Destination Input */}
                <div>
                  <label htmlFor="target-destination-input" className="block text-xs font-semibold text-stone-300 mb-1.5">
                    Target Destination (Kerala / Location):
                  </label>
                  <div className="relative">
                    <input
                      id="target-destination-input"
                      type="text"
                      value={destination}
                      onChange={(e) => setDestination(e.target.value)}
                      placeholder="e.g., Home, Infopark Kakkanad, Technopark Trivandrum, Kozhikode Campus"
                      className="w-full bg-stone-950/90 border border-stone-700 rounded-xl px-4 py-3 pl-10 text-stone-100 text-sm focus:outline-none focus:border-emerald-500 transition-colors placeholder:text-stone-500"
                      required
                    />
                    <MapPin className="w-4 h-4 text-emerald-400 absolute left-3.5 top-3.5 pointer-events-none" />
                  </div>

                  {/* Kerala Preset Shortcuts */}
                  <div className="flex flex-wrap gap-2 mt-2.5">
                    {keralaPresetDestinations.map((preset) => {
                      const Icon = preset.icon;
                      return (
                        <button
                          key={preset.label}
                          type="button"
                          onClick={() => setDestination(preset.label)}
                          className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[11px] font-medium border transition-all cursor-pointer ${
                            destination === preset.label
                              ? 'bg-emerald-600 text-white border-emerald-500 shadow-md shadow-emerald-950'
                              : 'bg-stone-950 border-stone-800 text-stone-400 hover:text-stone-200 hover:border-stone-700'
                          }`}
                        >
                          <Icon className="w-3 h-3" />
                          <span>{preset.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Traveler Name & Custom Note */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="traveler-name-input" className="block text-xs font-semibold text-stone-300 mb-1.5">
                      Your Name / Traveler Name (Optional):
                    </label>
                    <input
                      id="traveler-name-input"
                      type="text"
                      value={travelerName}
                      onChange={(e) => setTravelerName(e.target.value)}
                      placeholder="e.g., Alex / Rahul / Ananya"
                      className="w-full bg-stone-950/90 border border-stone-700 rounded-xl px-3.5 py-2.5 text-stone-100 text-xs focus:outline-none focus:border-emerald-500 placeholder:text-stone-500"
                    />
                  </div>

                  <div>
                    <label htmlFor="trip-notes-input" className="block text-xs font-semibold text-stone-300 mb-1.5">
                      Trip Note / Route Details (Optional):
                    </label>
                    <input
                      id="trip-notes-input"
                      type="text"
                      value={tripNotes}
                      onChange={(e) => setTripNotes(e.target.value)}
                      placeholder="e.g., Traveled via KSRTC bus / MC Road safely"
                      className="w-full bg-stone-950/90 border border-stone-700 rounded-xl px-3.5 py-2.5 text-stone-100 text-xs focus:outline-none focus:border-emerald-500 placeholder:text-stone-500"
                    />
                  </div>
                </div>

                {/* Error Notice */}
                {errorMsg && (
                  <div className="bg-rose-950/60 border border-rose-800 rounded-xl p-3.5 text-rose-200 text-xs flex items-center gap-2.5">
                    <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                    <span>{errorMsg}</span>
                  </div>
                )}

                {/* Actions */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  {!isArmed ? (
                    <button
                      id="arm-destination-btn"
                      type="submit"
                      className="w-full py-3.5 px-5 rounded-xl bg-stone-800 hover:bg-stone-700 border border-stone-600 text-stone-200 font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer"
                    >
                      <Compass className="w-4 h-4 text-emerald-400" />
                      <span>Set Route & Arm Beacon</span>
                    </button>
                  ) : (
                    <button
                      id="disarm-beacon-btn"
                      type="button"
                      onClick={() => setIsArmed(false)}
                      className="w-full py-3.5 px-5 rounded-xl bg-stone-900 hover:bg-stone-800 border border-stone-700 text-stone-400 font-medium text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer"
                    >
                      <span>Edit Destination / Email</span>
                    </button>
                  )}

                  <button
                    id="confirm-arrival-trigger-btn"
                    type="button"
                    onClick={handleNotifyArrival}
                    disabled={isSending || !destination.trim() || !receiverEmail.trim()}
                    className={`w-full py-3.5 px-6 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2.5 transition-all shadow-xl cursor-pointer ${
                      isSending || !destination.trim() || !receiverEmail.trim()
                        ? 'bg-stone-800 text-stone-500 cursor-not-allowed border border-stone-700'
                        : 'bg-gradient-to-r from-emerald-600 via-emerald-500 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white shadow-emerald-950/60 border border-emerald-400/30 active:scale-[0.99]'
                    }`}
                  >
                    {isSending ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Locking GPS & Sending Email...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>I Have Arrived (Send Email Alert)</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}

            {/* Arrival Success Report */}
            <AnimatePresence>
              {arrivalSuccess && arrivalData && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.96 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-stone-950 border border-emerald-500/40 rounded-2xl p-6 sm:p-7 flex flex-col gap-5"
                >
                  <div className="flex items-center gap-3.5 bg-emerald-950/60 border border-emerald-600/50 rounded-xl p-4 text-emerald-200">
                    <div className="w-10 h-10 rounded-full bg-emerald-600 flex items-center justify-center text-white shrink-0 shadow-lg shadow-emerald-950/80">
                      <CheckCircle2 className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-white">
                        Safe Arrival Email Dispatched!
                      </h3>
                      <p className="text-xs text-emerald-300/90 mt-0.5">
                        Arrival confirmation sent to <strong className="text-white underline">{arrivalData.receiverEmail}</strong> with your live Google Maps coordinates and timestamp.
                      </p>
                    </div>
                  </div>

                  {/* Arrival Receipt Details */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-xs">
                    <div className="bg-stone-900/80 border border-stone-800 rounded-xl p-3.5 flex flex-col gap-1">
                      <span className="text-[11px] text-stone-400 font-medium uppercase tracking-wider">Sent To (Receiver)</span>
                      <span className="text-sm font-bold text-emerald-300 flex items-center gap-1.5">
                        <Mail className="w-4 h-4 text-emerald-400" />
                        {arrivalData.receiverEmail}
                      </span>
                    </div>

                    <div className="bg-stone-900/80 border border-stone-800 rounded-xl p-3.5 flex flex-col gap-1">
                      <span className="text-[11px] text-stone-400 font-medium uppercase tracking-wider">Destination</span>
                      <span className="text-sm font-bold text-white flex items-center gap-1.5">
                        <MapPin className="w-4 h-4 text-emerald-400" />
                        {arrivalData.destination}
                      </span>
                    </div>

                    <div className="bg-stone-900/80 border border-stone-800 rounded-xl p-3.5 flex flex-col gap-1">
                      <span className="text-[11px] text-stone-400 font-medium uppercase tracking-wider">Arrival Time</span>
                      <span className="text-sm font-bold text-white flex items-center gap-1.5">
                        <Clock className="w-4 h-4 text-amber-400" />
                        {arrivalData.timestamp} (IST)
                      </span>
                    </div>

                    <div className="bg-stone-900/80 border border-stone-800 rounded-xl p-3.5 flex flex-col gap-1 font-mono">
                      <span className="text-[11px] text-stone-400 font-medium uppercase tracking-wider">Coordinates</span>
                      <span className="text-xs font-semibold text-emerald-300">
                        {arrivalData.latitude.toFixed(6)}°, {arrivalData.longitude.toFixed(6)}°
                      </span>
                      <span className="text-[10px] text-stone-500">Accuracy: ±{arrivalData.accuracy}m</span>
                    </div>
                  </div>

                  {/* Navigation & Direct Multi-Channel Actions */}
                  <div className="flex flex-wrap items-center gap-3 pt-2">
                    <a
                      id="arrival-view-google-maps"
                      href={arrivalData.googleMapsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 min-w-[180px] py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
                    >
                      <MapPin className="w-4 h-4" />
                      <span>View Google Maps Pin</span>
                      <ExternalLink className="w-3.5 h-3.5 opacity-80" />
                    </a>

                    <a
                      id="arrival-open-email-client"
                      href={arrivalData.mailtoUrl}
                      className="py-2.5 px-4 bg-stone-900 hover:bg-stone-800 border border-emerald-500/40 text-emerald-300 hover:text-emerald-200 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
                    >
                      <Mail className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Open in Mail App</span>
                    </a>

                    <a
                      id="arrival-share-whatsapp"
                      href={arrivalData.whatsappUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="py-2.5 px-4 bg-[#25D366]/20 hover:bg-[#25D366]/30 border border-[#25D366]/40 text-[#25D366] rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                      <span>Share on WhatsApp</span>
                    </a>

                    <button
                      id="copy-arrival-link-btn"
                      onClick={() => handleCopyLink(arrivalData.googleMapsUrl)}
                      className="py-2.5 px-4 bg-stone-900 hover:bg-stone-800 border border-stone-700 text-stone-200 rounded-xl text-xs font-medium flex items-center justify-center gap-2 transition-colors cursor-pointer"
                    >
                      {copiedLink ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-emerald-400">Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5 text-stone-400" />
                          <span>Copy Map URL</span>
                        </>
                      )}
                    </button>

                    <button
                      id="reset-arrival-beacon-btn"
                      onClick={() => {
                        setArrivalSuccess(false);
                        setDestination('');
                        setTripNotes('');
                      }}
                      className="py-2.5 px-4 bg-stone-900 hover:bg-stone-800 border border-stone-800 text-stone-400 hover:text-stone-200 rounded-xl text-xs font-medium transition-colors cursor-pointer"
                    >
                      New Journey
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
}
