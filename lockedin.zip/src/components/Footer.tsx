import React from 'react';
import { Shield, Heart, MapPin, AlertCircle } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t border-stone-800/80 bg-stone-950 text-stone-400 text-xs py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col gap-8">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          {/* Brand */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-white tracking-tight text-sm font-['Space_Grotesk']">
                Lockedin
              </span>
              <p className="text-[11px] text-stone-500">
                Kerala, India • Live GPS Beacon & Personal Safety Network
              </p>
            </div>
          </div>

          {/* Quick Links */}
          <div className="flex flex-wrap items-center gap-5 text-[11px] text-stone-400">
            <a href="#location-finder" className="hover:text-rose-400 transition-colors">Find Location</a>
            <a href="#destination-arrival" className="hover:text-emerald-400 transition-colors">Send Arrival Email</a>
            <a href="#safety-suite" className="hover:text-amber-400 transition-colors">Kerala Helplines</a>
            <a href="#roadside-guide" className="hover:text-orange-400 transition-colors">Roadside Checklist</a>
            <a href="#creator-profile" className="hover:text-rose-400 transition-colors">Creator: Vishnu Binu</a>
          </div>
        </div>

        {/* Disclaimer banner */}
        <div className="bg-stone-900/60 border border-stone-800/80 rounded-xl p-3.5 flex items-start gap-2.5 text-[11px] text-stone-400">
          <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <p>
            <strong>Kerala Emergency Notice:</strong> Lockedin is an auxiliary emergency location broadcast system. In life-threatening emergencies anywhere in Kerala, immediately dial <strong>112 (Kerala Unified Emergency)</strong>, <strong>100 (Police)</strong>, or <strong>1515 (Pink Police Patrol)</strong>.
          </p>
        </div>

        {/* Bottom bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-stone-900 text-[11px] text-stone-500">
          <div className="flex items-center gap-2">
            <span>© {new Date().getFullYear()} Lockedin. Created by</span>
            <span className="text-stone-200 font-semibold">Vishnu Binu</span>
            <span className="text-stone-600">•</span>
            <span className="text-emerald-400">Kerala, India</span>
          </div>

          <div className="flex items-center gap-1">
            <span>HTML5 High-Precision Geolocation & Instant Arrival Dispatch</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
