export interface LocationData {
  latitude: number;
  longitude: number;
  accuracy: number;
  altitude: number | null;
  speed: number | null;
  heading: number | null;
  timestamp: string;
  googleMapsUrl: string;
  osmUrl: string;
  appleMapsUrl: string;
}

export type StepStatus = 'idle' | 'locating' | 'sending' | 'success' | 'error';

export interface EmergencyContact {
  id: string;
  name: string;
  phone: string;
  relation: string;
  isCustom?: boolean;
}

export interface SafetyCheckIn {
  active: boolean;
  durationMinutes: number;
  remainingSeconds: number;
  destination: string;
  contactName: string;
  contactPhone: string;
}

export interface RoadsideSafetyTip {
  id: string;
  title: string;
  category: 'Mechanical' | 'Night Drive' | 'Accident' | 'Weather' | 'Weather & Monsoon' | 'Ghat Roads';
  summary: string;
  steps: string[];
  iconName: string;
}
