import React, { useState } from 'react';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import LocationFinder from './components/LocationFinder';
import DestinationArrival from './components/DestinationArrival';
import SafetyFeatures from './components/SafetyFeatures';
import CreatorProfile from './components/CreatorProfile';
import Footer from './components/Footer';
import { siren } from './utils/audioSiren';
import { LocationData } from './types';

export default function App() {
  const [currentLocation, setCurrentLocation] = useState<LocationData | null>(null);
  const [isSirenActive, setIsSirenActive] = useState<boolean>(false);

  const handleSirenToggle = () => {
    if (isSirenActive) {
      siren.stop();
      setIsSirenActive(false);
    } else {
      siren.start();
      setIsSirenActive(true);
    }
  };

  const scrollToFinder = () => {
    const el = document.getElementById('location-finder');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToSafety = () => {
    const el = document.getElementById('safety-suite');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-stone-950 text-stone-100 flex flex-col font-sans">
      {/* Global Siren Flashing Warning Border when active */}
      {isSirenActive && (
        <div className="fixed inset-0 pointer-events-none z-50 border-4 border-rose-600 animate-pulse" />
      )}

      {/* Navigation */}
      <Navbar
        onSirenToggle={handleSirenToggle}
        isSirenActive={isSirenActive}
      />

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col">
        {/* Hero Section */}
        <HeroSection
          onScrollToFinder={scrollToFinder}
          onScrollToSafety={scrollToSafety}
        />

        {/* Location Beacon Section (with "Find Their Location" Button) */}
        <LocationFinder
          onLocationCaptured={(loc) => setCurrentLocation(loc)}
        />

        {/* Destination Arrival Beacon & Hoster Email Alert System */}
        <DestinationArrival
          onLocationUpdate={(loc) => setCurrentLocation(loc)}
        />

        {/* Extended Safety Suite (SOS Siren, Check-In Timer, Hotlines, Roadside Guide) */}
        <SafetyFeatures
          currentLocation={currentLocation}
          isSirenActive={isSirenActive}
          onSirenToggle={handleSirenToggle}
        />

        {/* Creator Showcase: Vishnu Binu (@v15hhnu) */}
        <CreatorProfile />
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
}
