// Web Audio API emergency safety siren synthesizer
class EmergencySiren {
  private ctx: AudioContext | null = null;
  private osc1: OscillatorNode | null = null;
  private osc2: OscillatorNode | null = null;
  private gainNode: GainNode | null = null;
  private isPlaying = false;
  private timer: number | null = null;

  start() {
    if (this.isPlaying) return;

    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;

      this.ctx = new AudioCtx();
      this.gainNode = this.ctx.createGain();
      this.gainNode.gain.setValueAtTime(0.3, this.ctx.currentTime);
      this.gainNode.connect(this.ctx.destination);

      // Primary siren oscillator
      this.osc1 = this.ctx.createOscillator();
      this.osc1.type = 'sawtooth';
      this.osc1.frequency.setValueAtTime(600, this.ctx.currentTime);
      this.osc1.connect(this.gainNode);
      this.osc1.start();

      // Sub-harmonic oscillator for penetrating alarm sound
      this.osc2 = this.ctx.createOscillator();
      this.osc2.type = 'sine';
      this.osc2.frequency.setValueAtTime(900, this.ctx.currentTime);
      this.osc2.connect(this.gainNode);
      this.osc2.start();

      this.isPlaying = true;

      // Frequency modulation cycle for realistic emergency wail (600Hz - 1200Hz)
      let goingUp = true;
      const modInterval = 60; // ms
      this.timer = window.setInterval(() => {
        if (!this.ctx || !this.osc1 || !this.osc2) return;
        const now = this.ctx.currentTime;
        const freq1 = goingUp ? 1100 : 650;
        const freq2 = goingUp ? 1400 : 850;
        this.osc1.frequency.linearRampToValueAtTime(freq1, now + 0.4);
        this.osc2.frequency.linearRampToValueAtTime(freq2, now + 0.4);
        goingUp = !goingUp;
      }, 500);
    } catch (e) {
      console.warn('AudioContext not permitted yet:', e);
    }
  }

  stop() {
    if (!this.isPlaying) return;
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
    try {
      if (this.osc1) {
        this.osc1.stop();
        this.osc1.disconnect();
      }
      if (this.osc2) {
        this.osc2.stop();
        this.osc2.disconnect();
      }
      if (this.gainNode) {
        this.gainNode.disconnect();
      }
      if (this.ctx && this.ctx.state !== 'closed') {
        this.ctx.close();
      }
    } catch (e) {
      console.error(e);
    }
    this.isPlaying = false;
    this.ctx = null;
  }

  status(): boolean {
    return this.isPlaying;
  }
}

export const siren = new EmergencySiren();
